const express = require("express");
const mongoose = require("mongoose");
const db = require("./database/db.js");

const nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport({
  //   host: "smtp.gmail.com",
  //   port: 587,
  //   secure: false, // true for port 465, false for other ports
  service: "gmail",
  auth: {
    user: "vaishnavibhoi120@gmail.com",
    pass: "dggg msxk lndq cbaf",
  },
});

db();
const Schema = mongoose.Schema();
const userSchema = mongoose.Schema({
  name: String,
  email: String,
  mobile: Number,
});
const usermodel = mongoose.model("newUser", userSchema);

var app = express();
app.use(express.json()); //use to srd data in json formate

app.use(express.urlencoded());

app.get("/add", function (req, res) {
  res.render("Adduser.ejs");
});

app.get("/show", async function (req, res) {
  //
  try {
    var result = await usermodel.find();
    res.render("showuser.ejs", { data: result });
  } catch (err) {
    res.send(err.message);
  }
});
app.post("/useraction", async function (req, res) {
  //  console.log(req.body);

  try {
    var record = new usermodel(req.body);
      await record.save();
      main(req.body.email)
    res.redirect("/show");
  } catch (err) {
    res.send(err.message);
  }
});

async function main(emailid) {
 
  const info = await transporter.sendMail({
    from: '"Vaishhh💫" <vaishnavibhoi120@gmail.com>', // sender address
    // to: "adityanemade80@gmail.com , mahavir.v.navalkha@gmail.com", // list of receivers
    to: emailid,
    subject: "Abra Ka Dabra....👻", // Subject line
    //text: "Hello Adityaa", // plain text body
    html: "<b>Summing up college in a few precious words</b>", 
  });

  console.log("Message sent: %s", info.messageId);
  // Message sent: <d786aa62-4e0a-070a-47ed-0b0666549519@ethereal.email>
}


app.listen(9000);
